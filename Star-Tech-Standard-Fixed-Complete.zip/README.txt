STAR TECH STANDARD LTD — FIXED COMPLETE WEBSITE

Corrections included:
- WhatsApp corrected to +234 803 345 2862.
- Google Maps buttons use direct Google Maps search links; no separate XML map file is required.
- Removed broken image-file references. The Kat Power section has a built-in product presentation, so the page cannot show a broken PNG/JPG icon.
- Email set to info@startechstandard.com.
- Kat Power gasoline generators are presented as sales only; diesel-generator repair/service is clearly separated.
- Three Lagos Kat Power display locations are included.
- Mobile layout and navigation are included.

Upload BOTH index.html and style.css to the root of the GitHub Pages repository.
